﻿using System;
using System.ComponentModel;
using System.Drawing.Printing;
using System.IO;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace WebPrint
{
    public partial class PrintApp : Form
    {
        PrinterSettings settings = new PrinterSettings();
        public PrintApp()
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            this.Visible = false;
            printername.Text = settings.PrinterName;
            trayIcon.Visible = true;
            trayIcon.ContextMenuStrip = new ContextMenuStrip();
            trayIcon.ContextMenuStrip.Items.Add("Show", null, trayIcon_DoubleClick);
            trayIcon.ContextMenuStrip.Items.Add("Hide", null, trayIcon_hide);
            trayIcon.ContextMenuStrip.Items.Add("Exit", null, Exit);
            trayIcon.DoubleClick += new EventHandler(trayIcon_DoubleClick);
            this.Hide();
            backgroundWorker1.RunWorkerAsync();
        }

        void Exit(object sender, EventArgs e)
        {
            // Hide tray icon, otherwise it will remain shown until user mouses over it
            trayIcon.Visible = false;
            Application.Exit();
        }

        private void trayIcon_DoubleClick(object Sender, EventArgs e)
        {
            // Show the form when the user double clicks on the notify icon.
            // Activate the form.
            this.Activate();
            this.Visible = true;
            // Set the WindowState to normal if the form is minimized.
            this.WindowState = FormWindowState.Normal;
            this.Show();
        }
        private void trayIcon_hide(object Sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.Hide();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            HttpListener listener = new HttpListener();
            listener.Prefixes.Add("http://localhost:7000/");
            // listener.Prefixes.Add("https://localhost:7001/");
            listener.Start();
            Console.WriteLine("===================================================");
            Console.WriteLine($"Now Listening on: http://localhost:7000");
            // Console.WriteLine($"Now Listening on: https://localhost:7001");
            Console.WriteLine("===================================================");
            while (true)
            {
                try
                {
                    Console.WriteLine("Waiting For Request.....");
                    var context = listener.GetContext();
                    var request = context.Request;
                    var response = context.Response;
                    if (request.HttpMethod == "OPTIONS")
                    {
                        response.AppendHeader("Access-Control-Allow-Headers", "*");
                        response.AppendHeader("Access-Control-Allow-Origin", "*");
                        Console.WriteLine("Preflight Request.....");
                        string Response = "Preflight Success";
                        byte[] RespBuffer = Encoding.UTF8.GetBytes(Response);
                        response.ContentLength64 = RespBuffer.Length;
                        System.IO.Stream output = response.OutputStream;
                        output.Write(RespBuffer, 0, RespBuffer.Length);
                        Console.WriteLine(Response);
                        Console.WriteLine("======================================================");
                        output.Close();
                    }
                    else
                    {
                        response.AppendHeader("Access-Control-Allow-Headers", "*");
                        response.AppendHeader("Access-Control-Allow-Origin", "*");
                        Console.WriteLine("Received Request.....");
                        PrinterSettings settings = new PrinterSettings();
                        Console.WriteLine($"Printer Name: {settings.PrinterName}");
                        string Response = "Print Success";
                        if (request.Url.ToString().ToUpper().EndsWith("PRINTBARCODE"))
                        {
                            
                            response.StatusCode = (int)HttpStatusCode.OK;
                            Response = "Print Success";
                        }
                        else if (request.Url.ToString().ToUpper().EndsWith("PRINTDATA"))
                        {
                            StreamReader streamToPrint = new StreamReader(request.InputStream, request.ContentEncoding);
                            string data = streamToPrint.ReadToEnd();//File.ReadAllText(FilePath);//streamToPrint.ReadToEnd();
                            webBrowser.DocumentText = data.ToString();
                            // webBrowser.Visible = false;
                            // webBrowser.Width = 0;
                            // webBrowser.Height = 0;
                            // webBrowser.Document.Write(data);
                            // webBrowser.ShowPrintPreviewDialog();
                            webBrowser.Print();
                            response.StatusCode = (int)HttpStatusCode.OK;
                            Response = "Print Success";
                        }
                        else
                        {
                            response.StatusCode = (int)HttpStatusCode.BadRequest;
                            Response = "Print Failure";
                        }
                        
                        byte[] RespBuffer = Encoding.UTF8.GetBytes(Response);
                        response.ContentLength64 = RespBuffer.Length;
                        System.IO.Stream output = response.OutputStream;
                        output.Write(RespBuffer, 0, RespBuffer.Length);
                        Console.WriteLine(Response);
                        Console.WriteLine("======================================================");
                        output.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.StackTrace);
                }
            }
        }
    }
}
