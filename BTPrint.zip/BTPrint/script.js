const button = document.getElementById("getDetails");
const details = document.getElementById("details");

const devstatus = document.getElementById("devstatus");
const buffers = [];
var cmds = "";

function write() {

    // this.parse(this.textarea.value);
    try {


        alert("Preparing buffer");
        const txt = "this is my fist\nbt print from web";

        const encoder = new TextEncoder();
        const ecoder = new TextDecoder();
        alert(1);
        //buffers = [];
        alert(2);
        txt.split('\n').forEach(line => {
            alert(3);
            const l = line + '\n';
            alert(4);
            const buffer = this.encoder.encode(l.padEnd(
                l.length + 8 - (l.length % 8), '\0'));
            alert(5);
            let slices = [];
            alert(6);
            for (var i = 0; i < buffer.length; i += 8) {
                slices.push(buffer.slice(i, i + 8));
            }
            alert(7);
            buffers.push(slices);
            alert(8);
        });
        console.log(buffers.flat());

        alert("buffers : " + buffers);
    } catch (error) {
        alert(error)
    }
    /*
        buffers.flat().forEach(slice => {
            this.writer(slice);
        });
        */
}
/*
writer(slice) {
    this.device.transferOut(1, slice.buffer).then(() => { });

}
*/


function printdata() {
    //Create ESP/POS commands for sample label
    //alert(1)
    var esc = '\x1B'; //ESC byte in hex notation
    var newLine = '\x0A'; //LF byte in hex notation
    //alert(2)
    cmds = esc + "@"; //Initializes the printer (ESC @)
    //alert(3)
    cmds += esc + '!' + '\x38'; //Emphasized + Double-height + Double-width mode selected (ESC ! (8 + 16 + 32)) 56 dec => 38 hex
    cmds += 'BEST DEAL STORES'; //text to print
    //return;
    cmds += newLine + newLine;
    cmds += esc + '!' + '\x00'; //Character font A selected (ESC ! 0)
    cmds += 'COOKIES                   5.00';
    cmds += newLine;
    cmds += 'MILK 65 Fl oz             3.78';
    cmds += newLine + ' ' + newLine;
    cmds += 'SUBTOTAL                       8.78';
    cmds += newLine;
    cmds += 'TAX 5%                    0.44';
    cmds += newLine;
    cmds += 'TOTAL                     9.22';
    cmds += newLine;
    cmds += 'CASH TEND                10.00';
    cmds += newLine;
    // cmds += 'CASH DUE                  0.78';
    // cmds += newLine + '&' + newLine;
    // cmds += esc + '!' + '\x18'; //Emphasized + Double-height mode selected (ESC ! (16 + 8)) 24 dec => 18 hex
    // cmds += 'ITEMS SOLD 2';
    // cmds += esc + '!' + '\x00'; //Character font A selected (ESC ! 0)
    // cmds += newLine + '&' + newLine;
    // cmds += '11/03/13  19:53:17';
	// cmds += newLine + '&' + newLine;
	// cmds += newLine + '&' + newLine;
}

function printdata1() {
    //Create ESP/POS commands for sample label
    //alert(1)
    var esc = '\x1B'; //ESC byte in hex notation
    var newLine = '\x0A'; //LF byte in hex notation
    //alert(2)
    cmds = esc + "@"; //Initializes the printer (ESC @)
    //alert(3)
    // // // 
    cmds += 'CASH DUE                  0.78';
    cmds += newLine + '' + newLine;
    cmds += esc + '!' + '\x18'; //Emphasized + Double-height mode selected (ESC ! (16 + 8)) 24 dec => 18 hex
    cmds += 'ITEMS SOLD 2';
    cmds += esc + '!' + '\x00'; //Character font A selected (ESC ! 0)
    cmds += newLine + '' + newLine;
    cmds += '11/03/13  19:53:17';
	cmds += newLine + '' + newLine;
	cmds += newLine + '' + newLine;
}


button.addEventListener("click", async () => {
    try {
        // Request the Bluetooth device through browser

        const primaryServiceUuid = 'e7810a71-73ae-499d-8c15-faa9aef0c3f2';
		// const primaryServiceUuid = 'primary_service';
        //'49535343-fe7d-4ae5-8fa9-9fafd205e455';
        const receiveCharUuid = '12345678-1234-5678-1234-56789abcdef1';
        const sendCharUuid = 'bef8d6c9-9c21-4c9e-b632-bd58c1009f9f';

        /*
                const device =await navigator.bluetooth
                .requestDevice({
                   filters: [{
                     services: [primaryServiceUuid]
                   }]           
                });
                
        */
		let device;
		navigator.bluetooth.requestDevice({
            // optionalServices: ["generic_access","alert_notification", "object_transfer", "transport_discovery"],
			// optionalServices: ['00001825-0000-1000-8000-00805f9b34fb', '00001824-0000-1000-8000-00805f9b34fb'],
            optionalServices: ['e7810a71-73ae-499d-8c15-faa9aef0c3f2', '49535343-fe7d-4ae5-8fa9-9fafd205e455',
                // , '12345678-1234-5678-1234-56789abcdef1',
                sendCharUuid],
            acceptAllDevices: true,

        }).then(async (device) => {
        let deviceName = device.gatt.device.name;
        const server = await device.gatt.connect();
		const services = await server.getPrimaryService(primaryServiceUuid);
		// const services = await server.getPrimaryServices();
		// const charactersssss = await services[0].getCharacteristics();
		// const charactersssss1 = await services[1].getCharacteristics();
		// const charactersssss2 = await services[2].getCharacteristics();
			// server.getPrimaryServices().then(async (service) => {
				const sendCharacteristic = await services.getCharacteristic(sendCharUuid);

        //alert("getting print data")
        printdata();
        //alert(cmds);
//        var result = [];
	var encoder = new TextEncoder('utf-8');
			//alert(cmds);
	var myresult = encoder.encode(cmds);
	
        // alert("convert print data to Uint8Array")
  //      for (var i = 0; i < cmds.length; i += 2) {
    //        result.push(parseInt(cmds.substring(i, i + 2), 16));
      //  }
        //result = Uint8Array.from(result)
        // alert("Send command")
        sendCharacteristic.writeValue(myresult).then(() => {
			
			printdata1();
			//alert(cmds);
	var myresult1 = encoder.encode(cmds);
			sendCharacteristic.writeValue(myresult1);
			alert("command done");
		});		
			// });
		});
		
        // const device = await navigator.bluetooth.requestDevice({
            // // optionalServices: ["battery_service", "device_information"],
            // // optionalServices: ['e7810a71-73ae-499d-8c15-faa9aef0c3f2', '49535343-fe7d-4ae5-8fa9-9fafd205e455'
                // // , '12345678-1234-5678-1234-56789abcdef1',
                // // sendCharUuid],
            // acceptAllDevices: true,

        // });
		
		// console.log(JSON.stringify(device));


        // // Connect to the GATT server
        // // We also get the name of the Bluetooth device here
        // let deviceName = device.gatt.device.name;
        // const server = await device.gatt.connect();

        // //alert("getting service")
        // const service = await server.getPrimaryService(primaryServiceUuid);
        // //alert("getting send characteristic")

        // const sendCharacteristic = await service.getCharacteristic(sendCharUuid);

        // //alert("getting print data")
        // printdata();
        // //alert(cmds);
// //        var result = [];
	// var encoder = new TextEncoder('utf-8');
			// //alert(cmds);
	// var myresult = encoder.encode(cmds);
	
        // // alert("convert print data to Uint8Array")
  // //      for (var i = 0; i < cmds.length; i += 2) {
    // //        result.push(parseInt(cmds.substring(i, i + 2), 16));
      // //  }
        // //result = Uint8Array.from(result)
        // // alert("Send command")
        // sendCharacteristic.writeValue(myresult).then(() => {
			
			// printdata1();
			// //alert(cmds);
	// var myresult1 = encoder.encode(cmds);
			// sendCharacteristic.writeValue(myresult1);
			// alert("command done");
		// });		
		// setTimeout(function() {
		// }, 10);
/*
        const buffers = [];
        var txt = "sample text";
        var encoder = new TextEncoder();
        txt.split('\n').forEach(line => {
          const l = line + '\n';
          const buffer = encoder.encode(l.padEnd(
            l.length + 8 - (l.length % 8), '\0'));
          let slices = [];
          for (var i = 0; i < buffer.length; i += 8){
              slices.push(buffer.slice(i, i + 8));
          }
          buffers.push(slices);
        });
        console.log(buffers.flat());
    
        sendCharacteristic.writeValue(buffers);
*/

        /*buffers.flat().forEach(slice => {
            //this.writer(slice);
            //device.transferOut(1, slice.buffer).then(() => { });
            //sendCharacteristic.writeValue(1, slice.buffer).then(() => { });
            
        });*/

        
        //alert(buffers.flat())

        /*
        alert("getting buffer data")
        write();
        alert("writing to bt print")
        buffers.flat().forEach(slice => {
            //this.writer(slice);
            sendCharacteristic.writeValue(slice);
        });
        alert("writing done")
        */



        // Getting the services we mentioned before through GATT server
        //const batteryService = await server.getPrimaryService("battery_service");
        //alert("batteryService:" + batteryService);
        //const infoService = await server.getPrimaryService("device_information");
        //alert("infoService:" + infoService);

        /* error
        // Getting the current battery level
        const batteryLevelCharacteristic = await batteryService.getCharacteristic(
            "battery_level"
        );
        // Convert recieved buffer to number
        const batteryLevel = await batteryLevelCharacteristic.readValue();
        const batteryPercent = await batteryLevel.getUint8(0);
        */


        // Getting device information
        // We will get all characteristics from device_information
        /*
        const infoCharacteristics = await infoService.getCharacteristics();
        console.log(infoCharacteristics);
        let infoValues = [];
        const promise = new Promise((resolve, reject) => {
            infoCharacteristics.forEach(async (characteristic, index, array) => {
                // Returns a buffer
                const value = await characteristic.readValue();
                console.log(new TextDecoder().decode(value));
                // Convert the buffer to string
                infoValues.push(new TextDecoder().decode(value));
                if (index === array.length - 1) resolve();
            });
        });
        


        promise.then(() => {
            // Display all the information on the screen
            // use innerHTML
            details.innerHTML = `
                Device Name - ${deviceName}<br />
                Battery Level - ${batteryPercent}%<br />
                Device Information:
                <ul>
                    ${infoValues.map((value) => `<li>${value}</li>`).join("")}
                </ul> 
                `;
        });
        */
    } catch (err) {
        console.log(err);
        alert("An error occured while fetching device details\n" + err);
    }
});
