const button = document.getElementById("getDetails");
const details = document.getElementById("details");

const devstatus = document.getElementById("devstatus");
const buffers = [];
var cmds = "";
const esc = '\x1B';
const newLine = '\x0A';

function GetPrintContext(input, isHeader) {
    let res = esc + "@";
    if (isHeader) {
        res += esc + '!' + '\x38';
    } else {
        res += esc + '!' + '\x00';
    }
    res += input;
    res += newLine;
    return res;
}

function GetEndLine() {
	return newLine + newLine;
}

const Inputs = [
    'Shirt                                     10.00',
    'Pant                                     120.00',
    'Shoe                                     111.00',
    'Belt                                     250.00',
    'Watch                                      6.00',
    'Sun Glass                                 18.00',
    'Phone                                   1000.00',
    'Laptop                                 20000.00',
    'Shirt                                     10.00',
    'Pant                                     120.00',
    'Shoe                                     111.00',
    'Belt                                     250.00',
    'Watch                                      6.00',
    'Sun Glass                                 18.00',
    'Phone                                   1000.00',
    'Laptop                                 20000.00',
    'Shirt                                     10.00',
    'Pant                                     120.00',
    'Shoe                                     111.00',
    'Belt                                     250.00',
    'Watch                                      6.00',
    'Sun Glass                                 18.00',
    'Phone                                   1000.00',
    'Laptop                                 20000.00',
    'Shirt                                     10.00',
    'Pant                                     120.00',
    'Shoe                                     111.00',
    'Belt                                     250.00',
    'Watch                                      6.00',
    'Sun Glass                                 18.00',
    'Phone                                   1000.00',
    'Laptop                                 20000.00',
	'===============================================',
	'SubTotal                               53000.00',
	'Discount                                2500.00',
	'GST 5%                                   500.00',
	'===============================================',
	'Total                                  50000.00',
	'===============================================',
	'               Thank You - Kazito              ',
	'===============================================',
];

button.addEventListener("click", async() => {
    try {
        const primaryServiceUuid = 'e7810a71-73ae-499d-8c15-faa9aef0c3f2';
        const receiveCharUuid = '12345678-1234-5678-1234-56789abcdef1';
        const sendCharUuid = 'bef8d6c9-9c21-4c9e-b632-bd58c1009f9f';
        let device;
        navigator.bluetooth.requestDevice({
            optionalServices: ['e7810a71-73ae-499d-8c15-faa9aef0c3f2', '49535343-fe7d-4ae5-8fa9-9fafd205e455',
                sendCharUuid],
            acceptAllDevices: true,
        }).then(async(device) => {
            let deviceName = device.gatt.device.name;
            const server = await device.gatt.connect();
            const services = await server.getPrimaryService(primaryServiceUuid);
            const sendCharacteristic = await services.getCharacteristic(sendCharUuid);
            var encoder = new TextEncoder('utf-8');

            var headres = encoder.encode(GetPrintContext('Kazito Print', true));
            await sendCharacteristic.writeValue(headres);
            for (i = 0; i < Inputs.length; i++) {
                var myresult = encoder.encode(GetPrintContext(Inputs[i], false));
                await sendCharacteristic.writeValue(myresult);
            }
			var finalout = encoder.encode(GetEndLine());
			await sendCharacteristic.writeValue(finalout);
        });
    } catch (err) {
        console.log(err);
        alert("An error occured while fetching device details\n" + err);
    }
});
